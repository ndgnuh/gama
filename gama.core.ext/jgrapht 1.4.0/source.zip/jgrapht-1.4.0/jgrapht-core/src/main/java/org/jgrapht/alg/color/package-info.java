/**
 * Graph coloring algorithms.
 */
package org.jgrapht.alg.color;
