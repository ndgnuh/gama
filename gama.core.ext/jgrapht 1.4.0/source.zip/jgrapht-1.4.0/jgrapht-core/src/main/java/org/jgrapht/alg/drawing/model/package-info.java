/**
 * Graph Drawing Basic Types and Models.
 */
package org.jgrapht.alg.drawing.model;
