/**
 * Algorithm related interfaces.
 */
package org.jgrapht.alg.interfaces;
