# WMS Module

## Recent Development

The WMS module has been stable since 2.2.x.

It has subsequently been refactored to use apache httpclient.

## Module Status

The wms module is stable, we would like some assistence implementing WMS
Post support (in order to handle large SLD documents).

## IP Review

Review complete - see [REVIEW.md](REVIEW.md).