package org.locationtech.jtstest.testbuilder;

import javax.swing.ImageIcon;

public class AppIcons {
  public static ImageIcon EXECUTE = IconLoader.icon("Execute.png");
  public static ImageIcon SAVE_IMAGE = IconLoader.icon("SaveImage.png");
  public static ImageIcon UNDO = IconLoader.icon("Undo.png");
}
