/**
 * Algorithms for testing planarity of the graphs
 */
package org.jgrapht.alg.planar;
